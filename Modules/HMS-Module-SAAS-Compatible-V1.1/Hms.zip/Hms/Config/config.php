<?php

return [
    'name' => 'Hms',
    'module_version' => '1.1',
    'pid' => '18',
];
